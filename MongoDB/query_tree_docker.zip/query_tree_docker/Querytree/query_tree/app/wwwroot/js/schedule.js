(function(){ko.bindingHandlers.pickatime={init:function(a,b,c){var d,e,f,g,h,i,j,k,l,m,n,o,p;n=b(),i={clear:"Clear",format:"hh:i A",formatLabel:void 0,formatSubmit:void 0,hiddenPrefix:void 0,hiddenSuffix:"_submit",editable:void 0,interval:30,min:void 0,max:void 0,disable:void 0,container:void 0,onStart:void 0,onRender:void 0,onOpen:void 0,onClose:void 0,onSet:void 0,onStop:void 0,klass:{input:"picker__input",active:"picker__input--active",picker:"picker picker--time",opened:"picker--opened",focused:"picker--focused",holder:"picker__holder",frame:"picker__frame",wrap:"picker__wrap",box:"picker__box",list:"picker__list",listItem:"picker__list-item",disabled:"picker__list-item--disabled",selected:"picker__list-item--selected",highlighted:"picker__list-item--highlighted",viewset:"picker__list-item--viewset",now:"picker__list-item--now",buttonClear:"picker__button--clear"}},k=c.get("pickatime_options"),j="function"==typeof k?k():k||{};for(h in j)m=j[h],i[h]=m;p=function(a){return a.attr("autocomplete","off").pickatime(i).pickatime("picker")},i.clear_button_addon||i.clock_addon?(o=(new Date).getTime(),i.container="#"+o,g="before"===i.clock_addon?"before":"after",f="before"===i.clear_button_addon?"before":"after",e=i.clock_addon?$("<span class='input-group-addon'><i style='color: navy; cursor: pointer'title='A time picker appears when interacting with this field'class='fa fa-clock-o'></i></span>"):void 0,d=i.clear_button_addon?$("<span class='input-group-addon'><i style='color: navy; cursor: pointer'title='Click to clear time'class='fa fa-times'></i></span>"):void 0,l=p($(a).wrap($("<div id="+o+"></div>")).wrap($("<div class='input-group'></div>"))),$(a)[f](d),$(a)[g](e),i.clock_addon&&e.on("click",function(a){return l.open(),a.stopPropagation(),a.preventDefault()}),i.clear_button_addon&&d.on("click",function(a){return l.set("clear"),a.stopPropagation(),a.preventDefault()})):l=p($(a)),l.on("set",function(){var a;return a=l.get("select"),a?a!==n()?n(l.get()):void 0:n(a)}),ko.utils.domNodeDisposal.addDisposeCallback(a,function(){return i.clock_addon&&e.off("click"),i.clear_button_addon&&d.off("click"),l.get("start")?l.stop():void 0})},update:function(a,b){var c,d,e;return e=b(),c=ko.unwrap(e),d=$(a).pickatime("picker"),null==c||""===c?void d.set("clear"):void d.set("select",c)}}}).call(this);
/*!
* pickadate.js v3.5.4, 2014/09/11
* By Amsul, http://amsul.ca
* Hosted on http://amsul.github.io/pickadate.js
* Licensed under MIT
*/
!function(a){"function"==typeof define&&define.amd?define("picker",["jquery"],a):"object"==typeof exports?module.exports=a(require("jquery")):this.Picker=a(jQuery)}(function(a){function b(f,g,h,k){function l(){return b._.node("div",b._.node("div",b._.node("div",b._.node("div",x.component.nodes(s.open),u.box),u.wrap),u.frame),u.holder)}function m(){v.data(g,x).addClass(u.input).attr("tabindex",-1).val(v.data("value")?x.get("select",t.format):f.value),t.editable||v.on("focus."+s.id+" click."+s.id,function(a){a.preventDefault(),x.$root[0].focus()}).on("keydown."+s.id,p),e(f,{haspopup:!0,expanded:!1,readonly:!1,owns:f.id+"_root"+(x._hidden?" "+x._hidden.id:"")})}function n(){x.$root.on({keydown:p,focusin:function(a){x.$root.removeClass(u.focused),a.stopPropagation()},"mousedown click":function(b){var c=b.target;c!=x.$root.children()[0]&&(b.stopPropagation(),"mousedown"!=b.type||a(c).is(":input")||"OPTION"==c.nodeName||(b.preventDefault(),x.$root[0].focus()))}}).on({focus:function(){v.addClass(u.target)},blur:function(){v.removeClass(u.target)}}).on("focus.toOpen",q).on("click","[data-pick], [data-nav], [data-clear], [data-close]",function(){var b=a(this),c=b.data(),d=b.hasClass(u.navDisabled)||b.hasClass(u.disabled),e=document.activeElement;e=e&&(e.type||e.href)&&e,(d||e&&!a.contains(x.$root[0],e))&&x.$root[0].focus(),!d&&c.nav?x.set("highlight",x.component.item.highlight,{nav:c.nav}):!d&&"pick"in c?x.set("select",c.pick).close(!0):c.clear?x.clear().close(!0):c.close&&x.close(!0)}),e(x.$root[0],"hidden",!0)}function o(){var b;t.hiddenName===!0?(b=f.name,f.name=""):(b=["string"==typeof t.hiddenPrefix?t.hiddenPrefix:"","string"==typeof t.hiddenSuffix?t.hiddenSuffix:"_submit"],b=b[0]+f.name+b[1]),x._hidden=a('<input type=hidden name="'+b+'"'+(v.data("value")||f.value?' value="'+x.get("select",t.formatSubmit)+'"':"")+">")[0],v.on("change."+s.id,function(){x._hidden.value=f.value?x.get("select",t.formatSubmit):""}).after(x._hidden)}function p(a){var b=a.keyCode,c=/^(8|46)$/.test(b);return 27==b?(x.close(),!1):void((32==b||c||!s.open&&x.component.key[b])&&(a.preventDefault(),a.stopPropagation(),c?x.clear().close():x.open()))}function q(a){a.stopPropagation(),"focus"==a.type&&x.$root.addClass(u.focused),x.open()}if(!f)return b;var r=!1,s={id:f.id||"P"+Math.abs(~~(Math.random()*new Date))},t=h?a.extend(!0,{},h.defaults,k):k||{},u=a.extend({},b.klasses(),t.klass),v=a(f),w=function(){return this.start()},x=w.prototype={constructor:w,$node:v,start:function(){return s&&s.start?x:(s.methods={},s.start=!0,s.open=!1,s.type=f.type,f.autofocus=f==document.activeElement,f.readOnly=!t.editable,f.id=f.id||s.id,"text"!=f.type&&(f.type="text"),x.component=new h(x,t),x.$root=a(b._.node("div",l(),u.picker,'id="'+f.id+'_root" tabindex="0"')),n(),t.formatSubmit&&o(),m(),t.container?a(t.container).append(x.$root):v.after(x.$root),x.on({start:x.component.onStart,render:x.component.onRender,stop:x.component.onStop,open:x.component.onOpen,close:x.component.onClose,set:x.component.onSet}).on({start:t.onStart,render:t.onRender,stop:t.onStop,open:t.onOpen,close:t.onClose,set:t.onSet}),r=c(x.$root.children()[0]),f.autofocus&&x.open(),x.trigger("start").trigger("render"))},render:function(a){return a?x.$root.html(l()):x.$root.find("."+u.box).html(x.component.nodes(s.open)),x.trigger("render")},stop:function(){return s.start?(x.close(),x._hidden&&x._hidden.parentNode.removeChild(x._hidden),x.$root.remove(),v.removeClass(u.input).removeData(g),setTimeout(function(){v.off("."+s.id)},0),f.type=s.type,f.readOnly=!1,x.trigger("stop"),s.methods={},s.start=!1,x):x},open:function(c){return s.open?x:(v.addClass(u.active),e(f,"expanded",!0),setTimeout(function(){x.$root.addClass(u.opened),e(x.$root[0],"hidden",!1)},0),c!==!1&&(s.open=!0,r&&j.css("overflow","hidden").css("padding-right","+="+d()),x.$root[0].focus(),i.on("click."+s.id+" focusin."+s.id,function(a){var b=a.target;b!=f&&b!=document&&3!=a.which&&x.close(b===x.$root.children()[0])}).on("keydown."+s.id,function(c){var d=c.keyCode,e=x.component.key[d],f=c.target;27==d?x.close(!0):f!=x.$root[0]||!e&&13!=d?a.contains(x.$root[0],f)&&13==d&&(c.preventDefault(),f.click()):(c.preventDefault(),e?b._.trigger(x.component.key.go,x,[b._.trigger(e)]):x.$root.find("."+u.highlighted).hasClass(u.disabled)||x.set("select",x.component.item.highlight).close())})),x.trigger("open"))},close:function(a){return a&&(x.$root.off("focus.toOpen")[0].focus(),setTimeout(function(){x.$root.on("focus.toOpen",q)},0)),v.removeClass(u.active),e(f,"expanded",!1),setTimeout(function(){x.$root.removeClass(u.opened+" "+u.focused),e(x.$root[0],"hidden",!0)},0),s.open?(s.open=!1,r&&j.css("overflow","").css("padding-right","-="+d()),i.off("."+s.id),x.trigger("close")):x},clear:function(a){return x.set("clear",null,a)},set:function(b,c,d){var e,f,g=a.isPlainObject(b),h=g?b:{};if(d=g&&a.isPlainObject(c)?c:d||{},b){g||(h[b]=c);for(e in h)f=h[e],e in x.component.item&&(void 0===f&&(f=null),x.component.set(e,f,d)),("select"==e||"clear"==e)&&v.val("clear"==e?"":x.get(e,t.format)).trigger("change");x.render()}return d.muted?x:x.trigger("set",h)},get:function(a,c){if(a=a||"value",null!=s[a])return s[a];if("value"==a)return f.value;if(a in x.component.item){if("string"==typeof c){var d=x.component.get(a);return d?b._.trigger(x.component.formats.toString,x.component,[c,d]):""}return x.component.get(a)}},on:function(b,c,d){var e,f,g=a.isPlainObject(b),h=g?b:{};if(b){g||(h[b]=c);for(e in h)f=h[e],d&&(e="_"+e),s.methods[e]=s.methods[e]||[],s.methods[e].push(f)}return x},off:function(){var a,b,c=arguments;for(a=0,namesCount=c.length;namesCount>a;a+=1)b=c[a],b in s.methods&&delete s.methods[b];return x},trigger:function(a,c){var d=function(a){var d=s.methods[a];d&&d.map(function(a){b._.trigger(a,x,[c])})};return d("_"+a),d(a),x}};return new w}function c(a){var b,c="position";return a.currentStyle?b=a.currentStyle[c]:window.getComputedStyle&&(b=getComputedStyle(a)[c]),"fixed"==b}function d(){if(j.height()<=h.height())return 0;var b=a('<div style="visibility:hidden;width:100px" />').appendTo("body"),c=b[0].offsetWidth;b.css("overflow","scroll");var d=a('<div style="width:100%" />').appendTo(b),e=d[0].offsetWidth;return b.remove(),c-e}function e(b,c,d){if(a.isPlainObject(c))for(var e in c)f(b,e,c[e]);else f(b,c,d)}function f(a,b,c){a.setAttribute(("role"==b?"":"aria-")+b,c)}function g(b,c){a.isPlainObject(b)||(b={attribute:c}),c="";for(var d in b){var e=("role"==d?"":"aria-")+d,f=b[d];c+=null==f?"":e+'="'+b[d]+'"'}return c}var h=a(window),i=a(document),j=a(document.documentElement);return b.klasses=function(a){return a=a||"picker",{picker:a,opened:a+"--opened",focused:a+"--focused",input:a+"__input",active:a+"__input--active",target:a+"__input--target",holder:a+"__holder",frame:a+"__frame",wrap:a+"__wrap",box:a+"__box"}},b._={group:function(a){for(var c,d="",e=b._.trigger(a.min,a);e<=b._.trigger(a.max,a,[e]);e+=a.i)c=b._.trigger(a.item,a,[e]),d+=b._.node(a.node,c[0],c[1],c[2]);return d},node:function(b,c,d,e){return c?(c=a.isArray(c)?c.join(""):c,d=d?' class="'+d+'"':"",e=e?" "+e:"","<"+b+d+e+">"+c+"</"+b+">"):""},lead:function(a){return(10>a?"0":"")+a},trigger:function(a,b,c){return"function"==typeof a?a.apply(b,c||[]):a},digits:function(a){return/\d/.test(a[1])?2:1},isDate:function(a){return{}.toString.call(a).indexOf("Date")>-1&&this.isInteger(a.getUTCDate())},isInteger:function(a){return{}.toString.call(a).indexOf("Number")>-1&&a%1===0},ariaAttr:g},b.extend=function(c,d){a.fn[c]=function(e,f){var g=this.data(c);return"picker"==e?g:g&&"string"==typeof e?b._.trigger(g[e],g,[f]):this.each(function(){var f=a(this);f.data(c)||new b(this,c,d,e)})},a.fn[c].defaults=d.defaults},b});

/*!
* Time picker for pickadate.js v3.5.4
* http://amsul.github.io/pickadate.js/time.htm
*/
!function(a){"function"==typeof define&&define.amd?define(["picker","jquery"],a):"object"==typeof exports?module.exports=a(require("./picker.js"),require("jquery")):a(Picker,jQuery)}(function(a,b){function c(a,b){var c=this,d=a.$node[0].value,e=a.$node.data("value"),f=e||d,g=e?b.formatSubmit:b.format;c.settings=b,c.$node=a.$node,c.queue={interval:"i",min:"measure create",max:"measure create",now:"now create",select:"parse create validate",highlight:"parse create validate",view:"parse create validate",disable:"deactivate",enable:"activate"},c.item={},c.item.clear=null,c.item.interval=b.interval||30,c.item.disable=(b.disable||[]).slice(0),c.item.enable=-function(a){return a[0]===!0?a.shift():-1}(c.item.disable),c.set("min",b.min).set("max",b.max).set("now"),f?c.set("select",f,{format:g,fromValue:!!d}):c.set("select",null).set("highlight",c.item.now),c.key={40:1,38:-1,39:1,37:-1,go:function(a){c.set("highlight",c.item.highlight.pick+a*c.item.interval,{interval:a*c.item.interval}),this.render()}},a.on("render",function(){var c=a.$root.children(),d=c.find("."+b.klass.viewset),e=function(a){return["webkit","moz","ms","o",""].map(function(b){return(b?"-"+b+"-":"")+a})},f=function(a,b){e("transform").map(function(c){a.css(c,b)}),e("transition").map(function(c){a.css(c,b)})};d.length&&(f(c,"none"),c[0].scrollTop=~~d.position().top-2*d[0].clientHeight,f(c,""))},1).on("open",function(){a.$root.find("button").attr("disabled",!1)},1).on("close",function(){a.$root.find("button").attr("disabled",!0)},1)}var d=24,e=60,f=12,g=d*e,h=a._;c.prototype.set=function(a,b,c){var d=this,e=d.item;return null===b?("clear"==a&&(a="select"),e[a]=b,d):(e["enable"==a?"disable":"flip"==a?"enable":a]=d.queue[a].split(" ").map(function(e){return b=d[e](a,b,c)}).pop(),"select"==a?d.set("highlight",e.select,c):"highlight"==a?d.set("view",e.highlight,c):"interval"==a?d.set("min",e.min,c).set("max",e.max,c):a.match(/^(flip|min|max|disable|enable)$/)&&("min"==a&&d.set("max",e.max,c),e.select&&d.disabled(e.select)&&d.set("select",e.select,c),e.highlight&&d.disabled(e.highlight)&&d.set("highlight",e.highlight,c)),d)},c.prototype.get=function(a){return this.item[a]},c.prototype.create=function(a,c,f){var i=this;return c=void 0===c?a:c,h.isDate(c)&&(c=[c.getHours(),c.getMinutes()]),b.isPlainObject(c)&&h.isInteger(c.pick)?c=c.pick:b.isArray(c)?c=+c[0]*e+ +c[1]:h.isInteger(c)||(c=i.now(a,c,f)),"max"==a&&c<i.item.min.pick&&(c+=g),"min"!=a&&"max"!=a&&(c-i.item.min.pick)%i.item.interval!==0&&(c+=i.item.interval),c=i.normalize(a,c,f),{hour:~~(d+c/e)%d,mins:(e+c%e)%e,time:(g+c)%g,pick:c}},c.prototype.createRange=function(a,c){var d=this,e=function(a){return a===!0||b.isArray(a)||h.isDate(a)?d.create(a):a};return h.isInteger(a)||(a=e(a)),h.isInteger(c)||(c=e(c)),h.isInteger(a)&&b.isPlainObject(c)?a=[c.hour,c.mins+a*d.settings.interval]:h.isInteger(c)&&b.isPlainObject(a)&&(c=[a.hour,a.mins+c*d.settings.interval]),{from:e(a),to:e(c)}},c.prototype.withinRange=function(a,b){return a=this.createRange(a.from,a.to),b.pick>=a.from.pick&&b.pick<=a.to.pick},c.prototype.overlapRanges=function(a,b){var c=this;return a=c.createRange(a.from,a.to),b=c.createRange(b.from,b.to),c.withinRange(a,b.from)||c.withinRange(a,b.to)||c.withinRange(b,a.from)||c.withinRange(b,a.to)},c.prototype.now=function(a,b){var c,d=this.item.interval,f=new Date,g=f.getHours()*e+f.getMinutes(),i=h.isInteger(b);return g-=g%d,c=0>b&&-d>=d*b+g,g+="min"==a&&c?0:d,i&&(g+=d*(c&&"max"!=a?b+1:b)),g},c.prototype.normalize=function(a,b){var c=this.item.interval,d=this.item.min&&this.item.min.pick||0;return b-="min"==a?0:(b-d)%c},c.prototype.measure=function(a,c,f){var g=this;return c||(c="min"==a?[0,0]:[d-1,e-1]),"string"==typeof c?c=g.parse(a,c):c===!0||h.isInteger(c)?c=g.now(a,c,f):b.isPlainObject(c)&&h.isInteger(c.pick)&&(c=g.normalize(a,c.pick,f)),c},c.prototype.validate=function(a,b,c){var d=this,e=c&&c.interval?c.interval:d.item.interval;return d.disabled(b)&&(b=d.shift(b,e)),b=d.scope(b),d.disabled(b)&&(b=d.shift(b,-1*e)),b},c.prototype.disabled=function(a){var c=this,d=c.item.disable.filter(function(d){return h.isInteger(d)?a.hour==d:b.isArray(d)||h.isDate(d)?a.pick==c.create(d).pick:b.isPlainObject(d)?c.withinRange(d,a):void 0});return d=d.length&&!d.filter(function(a){return b.isArray(a)&&"inverted"==a[2]||b.isPlainObject(a)&&a.inverted}).length,-1===c.item.enable?!d:d||a.pick<c.item.min.pick||a.pick>c.item.max.pick},c.prototype.shift=function(a,b){var c=this,d=c.item.min.pick,e=c.item.max.pick;for(b=b||c.item.interval;c.disabled(a)&&(a=c.create(a.pick+=b),!(a.pick<=d||a.pick>=e)););return a},c.prototype.scope=function(a){var b=this.item.min.pick,c=this.item.max.pick;return this.create(a.pick>c?c:a.pick<b?b:a)},c.prototype.parse=function(a,b,c){var d,f,g,i,j,k=this,l={};if(!b||"string"!=typeof b)return b;c&&c.format||(c=c||{},c.format=k.settings.format),k.formats.toArray(c.format).map(function(a){var c,d=k.formats[a],e=d?h.trigger(d,k,[b,l]):a.replace(/^!/,"").length;d&&(c=b.substr(0,e),l[a]=c.match(/^\d+$/)?+c:c),b=b.substr(e)});for(i in l)j=l[i],h.isInteger(j)?i.match(/^(h|hh)$/i)?(d=j,("h"==i||"hh"==i)&&(d%=12)):"i"==i&&(f=j):i.match(/^a$/i)&&j.match(/^p/i)&&("h"in l||"hh"in l)&&(g=!0);return(g?d+12:d)*e+f},c.prototype.formats={h:function(a,b){return a?h.digits(a):b.hour%f||f},hh:function(a,b){return a?2:h.lead(b.hour%f||f)},H:function(a,b){return a?h.digits(a):""+b.hour%24},HH:function(a,b){return a?h.digits(a):h.lead(b.hour%24)},i:function(a,b){return a?2:h.lead(b.mins)},a:function(a,b){return a?4:g/2>b.time%g?"a.m.":"p.m."},A:function(a,b){return a?2:g/2>b.time%g?"AM":"PM"},toArray:function(a){return a.split(/(h{1,2}|H{1,2}|i|a|A|!.)/g)},toString:function(a,b){var c=this;return c.formats.toArray(a).map(function(a){return h.trigger(c.formats[a],c,[0,b])||a.replace(/^!/,"")}).join("")}},c.prototype.isTimeExact=function(a,c){var d=this;return h.isInteger(a)&&h.isInteger(c)||"boolean"==typeof a&&"boolean"==typeof c?a===c:(h.isDate(a)||b.isArray(a))&&(h.isDate(c)||b.isArray(c))?d.create(a).pick===d.create(c).pick:b.isPlainObject(a)&&b.isPlainObject(c)?d.isTimeExact(a.from,c.from)&&d.isTimeExact(a.to,c.to):!1},c.prototype.isTimeOverlap=function(a,c){var d=this;return h.isInteger(a)&&(h.isDate(c)||b.isArray(c))?a===d.create(c).hour:h.isInteger(c)&&(h.isDate(a)||b.isArray(a))?c===d.create(a).hour:b.isPlainObject(a)&&b.isPlainObject(c)?d.overlapRanges(a,c):!1},c.prototype.flipEnable=function(a){var b=this.item;b.enable=a||(-1==b.enable?1:-1)},c.prototype.deactivate=function(a,c){var d=this,e=d.item.disable.slice(0);return"flip"==c?d.flipEnable():c===!1?(d.flipEnable(1),e=[]):c===!0?(d.flipEnable(-1),e=[]):c.map(function(a){for(var c,f=0;f<e.length;f+=1)if(d.isTimeExact(a,e[f])){c=!0;break}c||(h.isInteger(a)||h.isDate(a)||b.isArray(a)||b.isPlainObject(a)&&a.from&&a.to)&&e.push(a)}),e},c.prototype.activate=function(a,c){var d=this,e=d.item.disable,f=e.length;return"flip"==c?d.flipEnable():c===!0?(d.flipEnable(1),e=[]):c===!1?(d.flipEnable(-1),e=[]):c.map(function(a){var c,g,i,j;for(i=0;f>i;i+=1){if(g=e[i],d.isTimeExact(g,a)){c=e[i]=null,j=!0;break}if(d.isTimeOverlap(g,a)){b.isPlainObject(a)?(a.inverted=!0,c=a):b.isArray(a)?(c=a,c[2]||c.push("inverted")):h.isDate(a)&&(c=[a.getFullYear(),a.getMonth(),a.getDate(),"inverted"]);break}}if(c)for(i=0;f>i;i+=1)if(d.isTimeExact(e[i],a)){e[i]=null;break}if(j)for(i=0;f>i;i+=1)if(d.isTimeOverlap(e[i],a)){e[i]=null;break}c&&e.push(c)}),e.filter(function(a){return null!=a})},c.prototype.i=function(a,b){return h.isInteger(b)&&b>0?b:this.item.interval},c.prototype.nodes=function(a){var b=this,c=b.settings,d=b.item.select,e=b.item.highlight,f=b.item.view,g=b.item.disable;return h.node("ul",h.group({min:b.item.min.pick,max:b.item.max.pick,i:b.item.interval,node:"li",item:function(a){a=b.create(a);var i=a.pick,j=d&&d.pick==i,k=e&&e.pick==i,l=g&&b.disabled(a);return[h.trigger(b.formats.toString,b,[h.trigger(c.formatLabel,b,[a])||c.format,a]),function(a){return j&&a.push(c.klass.selected),k&&a.push(c.klass.highlighted),f&&f.pick==i&&a.push(c.klass.viewset),l&&a.push(c.klass.disabled),a.join(" ")}([c.klass.listItem]),"data-pick="+a.pick+" "+h.ariaAttr({role:"option",selected:j&&b.$node.val()===h.trigger(b.formats.toString,b,[c.format,a])?!0:null,activedescendant:k?!0:null,disabled:l?!0:null})]}})+h.node("li",h.node("button",c.clear,c.klass.buttonClear,"type=button data-clear=1"+(a?"":" disabled")+" "+h.ariaAttr({controls:b.$node[0].id})),"",h.ariaAttr({role:"presentation"})),c.klass.list,h.ariaAttr({role:"listbox",controls:b.$node[0].id}))},c.defaults=function(a){return{clear:"Clear",format:"h:i A",interval:30,klass:{picker:a+" "+a+"--time",holder:a+"__holder",list:a+"__list",listItem:a+"__list-item",disabled:a+"__list-item--disabled",selected:a+"__list-item--selected",highlighted:a+"__list-item--highlighted",viewset:a+"__list-item--viewset",now:a+"__list-item--now",buttonClear:a+"__button--clear"}}}(a.klasses().picker),a.extend("pickatime",c)});

// 'tools' Module
//
// Defines a number of different tool classes that can be used to populate
// the toolbar of the application workspace
//
// Depends on: nodes.js, knockout.js

tools = {
    TemplatesFolder: "/partials/"
};

tools.ToolBase = function(properties) {
    var instance = {};

    instance.Name = properties.Name;
    instance.Visible = properties.Visible;
    instance.Title = properties.Title;
    instance.Description = properties.Description;
    instance.SymbolPath = properties.SymbolPath;
    instance.CreatedCount = 0;
    instance.OpenOptionsOnDrop = false;
    instance.AllowConnectOnDrop = true;
    instance.MaxInputs = 0;
    instance.AllowImageExport = false;
    instance.HelpUrl = null;

    instance.createNode = function(name, y, x, id) {
        this.CreatedCount += 1;
        return new properties.NodeType({
            Name: name,
            Top: y, 
            Left: x, 
            SymbolPath: properties.SymbolPath,
            OptionsTemplateUrl: properties.OptionsTemplateUrl,
            Tool: this,
            Id: id
        });
    }

    instance.Colors = [
        [100, 100, 255],
        [255, 100, 100],
        [100, 255, 100],
        [100, 255, 255],
        [255, 255, 100],
        [255, 100, 255]
    ];

    instance.GetSeriesColor = function(seriesNumber, opacity) {
        var baseColor = instance.Colors[seriesNumber % instance.Colors.length].slice(0);
        var offset = 100 / Math.floor(seriesNumber / instance.Colors.length);
        if (seriesNumber >= instance.Colors.length) {
            for (var i = 0; i < baseColor.length; i++) {
                baseColor[i] -= offset;
            }
        }

        return "rgba(" + baseColor[0] + "," + baseColor[1] + "," + baseColor[2] + "," + opacity + ")";
    };

    return instance;
};

tools.DatabaseTable = function() {
    var instance = new tools.ToolBase({
        Name: "Data Table",
        Title: "Data Table",
        Visible: true,
        Description: "Loads a database table", 
        SymbolPath: "M15.499,23.438c-3.846,0-7.708-0.987-9.534-3.117c-0.054,0.236-0.09,0.48-0.09,0.737v3.877c0,3.435,4.988,4.998,9.625,4.998s9.625-1.563,9.625-4.998v-3.877c0-0.258-0.036-0.501-0.09-0.737C23.209,22.451,19.347,23.438,15.499,23.438zM15.499,15.943c-3.846,0-7.708-0.987-9.533-3.117c-0.054,0.236-0.091,0.479-0.091,0.736v3.877c0,3.435,4.988,4.998,9.625,4.998s9.625-1.563,9.625-4.998v-3.877c0-0.257-0.036-0.501-0.09-0.737C23.209,14.956,19.347,15.943,15.499,15.943zM15.5,1.066c-4.637,0-9.625,1.565-9.625,5.001v3.876c0,3.435,4.988,4.998,9.625,4.998s9.625-1.563,9.625-4.998V6.067C25.125,2.632,20.137,1.066,15.5,1.066zM15.5,9.066c-4.211,0-7.625-1.343-7.625-3c0-1.656,3.414-3,7.625-3s7.625,1.344,7.625,3C23.125,7.724,19.711,9.066,15.5,9.066z",
        NodeType: nodes.DatabaseTable,
        OptionsTemplateUrl: tools.TemplatesFolder + "DatabaseTable.html",
    });
    instance.OpenOptionsOnDrop = true;
    instance.HelpUrl = "http://querytreeapp.com/help/tools/data-table/"

    return instance;
};
        
tools.Join = function() {
    var instance = new tools.ToolBase({
        Name: "Join",
        Title: "Join",
        Visible: true,
        Description: "Link two tables together where two column values are the same", 
        SymbolPath: "M29.342,15.5L21.785999999999998,11.137V13.75H20.374999999999996C19.586999999999996,13.74,19.043999999999997,13.509,18.355999999999995,13.007C17.334999999999994,12.262,16.261999999999993,10.826,14.804999999999994,9.439C13.367,8.06,11.291,6.73,8.5,6.749H2.812V10.248999999999999H8.5C10.731,10.261,11.940999999999999,11.434,13.57,13.183C14.267,13.936,14.998000000000001,14.763,15.894,15.506C14.498000000000001,16.671,13.482,18.022,12.41,19.007C11.227,20.088,10.208,20.73,8.498000000000001,20.748H2.813V24.248H8.529C12.280999999999999,24.249000000000002,14.564,21.929000000000002,16.148,20.182000000000002C16.965,19.287000000000003,17.685,18.491000000000003,18.357,17.991000000000003C19.043,17.489000000000004,19.587,17.259000000000004,20.374,17.249000000000002H21.785999999999998V19.863000000000003L29.342,15.5Z",
        NodeType: nodes.Join,
        OptionsTemplateUrl: tools.TemplatesFolder + "Join.html"
    });
            
    instance.JoinType = ko.observableArray([
        { id: "Inner", text: "Only matches from both" }, // Inner Join
        { id: "LeftOuter", text: "All of Table 1, with matches from Table 2" }, // Left Outer Join
        { id: "RightOuter", text: "All of Table 2, with matches from Table 1" }, // Right Outer Join
        { id: "FullOuter", text: "All of both tables, matched where possible" }, // Full Outer Join
        { id: "Cross", text: "Every possible combination" } // Cross Join
    ]);
    instance.MaxInputs = 2;
    instance.HelpUrl = "http://querytreeapp.com/help/tools/join/"

    return instance;
};

tools.Filter = function() {
    var instance = new tools.ToolBase({
        Name: "Filter",
        Title: "Filter",
        Visible: true,
        Description: "Remove rows from a table that don't meet certain criteria", 
        SymbolPath: "M29.772,26.433L22.645999999999997,19.307C23.605999999999998,17.724,24.168999999999997,15.871999999999998,24.169999999999998,13.886C24.169,8.093,19.478,3.401,13.688,3.399C7.897,3.401,3.204,8.093,3.204,13.885C3.204,19.674,7.897,24.366,13.688,24.366C15.675,24.366,17.527,23.803,19.11,22.843L26.238,29.97L29.772,26.433ZM7.203,13.885C7.2090000000000005,10.303,10.106,7.407,13.687000000000001,7.399C17.266000000000002,7.407,20.165,10.303,20.171,13.885C20.163999999999998,17.465,17.266,20.361,13.687,20.369C10.106,20.361,7.209,17.465,7.203,13.885Z",
        NodeType: nodes.Filter,
        OptionsTemplateUrl: tools.TemplatesFolder + "Filter.html"
    });

    instance.Operators = ko.observableArray([
        { type: "EqualTo", simpleName: 'is equal to', number: true, text: true, date: true, bool: true, compareValue: true, showCaseSensitive: true },
        { type: "DoesNotEqual", simpleName: 'is not equal to', number: true, text: true, date: true, bool: true, compareValue: true, showCaseSensitive: true },
        { type: "GreaterThan", simpleName: 'is greater than', number: true, text: true, date: true, bool: false, compareValue: true, showCaseSensitive: false },
        { type: "GreaterThanOrEqualTo", simpleName: 'is greater than or equal to', number: true, text: true, date: true, bool: false, compareValue: true, showCaseSensitive: false },
        { type: "LessThan", simpleName: 'is less than', number: true, text: true, date: true, bool: false, compareValue: true, showCaseSensitive: false },
        { type: "LessThanOrEqualTo", simpleName: 'is less than or equal to', number: true, text: true, date: true, bool: false, compareValue: true, showCaseSensitive: false },
        { type: "StartsWith", simpleName: 'starts with', number: false, text: true, date: false, bool: false, compareValue: true, showCaseSensitive: true },
        { type: "EndsWith", simpleName: 'ends with', number: false, text: true, date: false, bool: false, compareValue: true, showCaseSensitive: true },
        { type: "Contains", simpleName: 'contains', number: false, text: true, date: false, bool: false, compareValue: true, showCaseSensitive: true },
        { type: "DoesNotContain", simpleName: 'doesn\'t contain', number: false, text: true, date: false, bool: false, compareValue: true, showCaseSensitive: true },
        { type: "IsEmpty", simpleName: 'is empty', number: true, text: true, date: true, bool: true, compareValue: false, showCaseSensitive: false },
        { type: "IsNotEmpty", simpleName: 'is not empty', number: true, text: true, date: true, bool: true, compareValue: false, showCaseSensitive: false },
        { type: "Last24Hours", simpleName: 'was in the last 24 hours', number: false, text: false, date: true, bool: false, compareValue: false, showCaseSensitive: false },
        { type: "Next24Hours", simpleName: 'is in the next 24 hours', number: false, text: false, date: true, bool: false, compareValue: false, showCaseSensitive: false },
        { type: "Last7Days", simpleName: 'was in the last 7 days', number: false, text: false, date: true, bool: false, compareValue: false, showCaseSensitive: false },
        { type: "Next7Days", simpleName: 'is in the next 7 days', number: false, text: false, date: true, bool: false, compareValue: false, showCaseSensitive: false },
        { type: "ThisMonth", simpleName: 'is this month', number: false, text: false, date: true, bool: false, compareValue: false, showCaseSensitive: false },
        { type: "NextMonth", simpleName: 'is next month', number: false, text: false, date: true, bool: false, compareValue: false, showCaseSensitive: false },
        { type: "LastMonth", simpleName: 'was last month', number: false, text: false, date: true, bool: false, compareValue: false, showCaseSensitive: false },
        { type: "Last90Days", simpleName: 'was in the last 90 days', number: false, text: false, date: true, bool: false, compareValue: false, showCaseSensitive: false },
        { type: "Next90Days", simpleName: 'is in the next 90 days', number: false, text: false, date: true, bool: false, compareValue: false, showCaseSensitive: false }
    ]);
    instance.MaxInputs = 1;
    instance.HelpUrl = "http://querytreeapp.com/help/tools/filter/";

    return instance;
};

tools.Sort = function() {
    var instance = new tools.ToolBase({ 
        Name: "Sort",
        Title: "Sort",
        Visible: true,
        Description: "Sort the rows into ascending or descending order of values", 
        SymbolPath: "M21.786,20.654C21.168000000000003,20.459,20.379,19.951,19.495,19.067C18.738,18.325,17.956,17.369,17.155,16.326C16.964000000000002,16.582,16.773,16.836000000000002,16.581,17.096C16.057,17.805,15.522,18.52,14.977,19.223C16.881,21.532999999999998,18.857,23.801,21.786,24.174999999999997V26.875999999999998L29.342000000000002,22.513999999999996L21.786,18.151999999999994V20.654ZM9.192,11.933C9.948,12.674,10.73,13.629999999999999,11.531,14.672C11.726,14.41,11.921000000000001,14.151,12.118,13.884C12.638,13.181000000000001,13.169,12.472000000000001,13.71,11.774000000000001C11.678,9.311,9.577000000000002,6.867000000000001,6.314000000000001,6.7490000000000006H2.814000000000001V10.249H6.314000000000001C6.969,10.223,7.996,10.735,9.192,11.933ZM21.786,10.341V12.876L29.342000000000002,8.512999999999998L21.786,4.149999999999998V6.796999999999997C19.882,7.015999999999997,18.361,8.144999999999998,17.035,9.440999999999997C14.839,11.623999999999997,12.919,14.607999999999997,11.024000000000001,16.979C9.157,19.416999999999998,7.283000000000001,20.866999999999997,6.312000000000001,20.75H2.812000000000001V24.25H6.312000000000001C8.497000000000002,24.221,10.191,22.984,11.652000000000001,21.557C13.846,19.372999999999998,15.768,16.39,17.661,14.018999999999998C19.205,12.003,20.746,10.679,21.786,10.341Z",
        NodeType: nodes.Sort,
        OptionsTemplateUrl: tools.TemplatesFolder + "Sort.html"
    });
    instance.MaxInputs = 1;
    instance.HelpUrl = "http://querytreeapp.com/help/tools/sort/";

    return instance;
};

tools.Select = function() {
    var instance = new tools.ToolBase({
        Name: "Select",
        Title: "Select",
        Visible: true,
        Description: "Pick which columns you want and in what order they should appear",
        SymbolPath: "M29.548,3.043c-1.081-0.859-2.651-0.679-3.513,0.401L16,16.066l-3.508-4.414c-0.859-1.081-2.431-1.26-3.513-0.401c-1.081,0.859-1.261,2.432-0.401,3.513l5.465,6.875c0.474,0.598,1.195,0.944,1.957,0.944c0.762,0,1.482-0.349,1.957-0.944L29.949,6.556C30.809,5.475,30.629,3.902,29.548,3.043zM24.5,24.5h-17v-17h12.756l2.385-3H6C5.171,4.5,4.5,5.171,4.5,6v20c0,0.828,0.671,1.5,1.5,1.5h20c0.828,0,1.5-0.672,1.5-1.5V12.851l-3,3.773V24.5z",
        NodeType: nodes.Select,
        OptionsTemplateUrl: tools.TemplatesFolder + "Select.html"
    });
    instance.MaxInputs = 1;
    instance.HelpUrl = "http://querytreeapp.com/help/tools/select/";

    return instance;
}

tools.Append = function() {
    var instance = new tools.ToolBase({ 
        Name: "Append",
        Title: "Append",
        Visible: true,
        Description: "Create a table from the child values on each row of the source table", 
        SymbolPath: "M26.679,7.858c-0.176-0.138-0.404-0.17-0.606-0.083l-9.66,4.183c-0.42,0.183-0.946,0.271-1.486,0.271c-0.753,0.002-1.532-0.173-2.075-0.412c-0.194-0.083-0.356-0.176-0.471-0.259c0.042-0.021,0.09-0.042,0.146-0.064l8.786-3.804l1.31,0.561V6.612c0-0.244-0.106-0.475-0.283-0.612c-0.176-0.138-0.406-0.17-0.605-0.083l-9.66,4.183c-0.298,0.121-0.554,0.268-0.771,0.483c-0.213,0.208-0.397,0.552-0.394,0.934c0,0.01,0.003,0.027,0.003,0.027v14.73c0,0.006-0.002,0.012-0.002,0.019c0,0.005,0.002,0.007,0.002,0.012v0.015h0.002c0.021,0.515,0.28,0.843,0.528,1.075c0.781,0.688,2.091,1.073,3.484,1.093c0.66,0,1.33-0.1,1.951-0.366l9.662-4.184c0.255-0.109,0.422-0.383,0.422-0.692V8.471C26.961,8.227,26.855,7.996,26.679,7.858zM20.553,5.058c-0.017-0.221-0.108-0.429-0.271-0.556c-0.176-0.138-0.404-0.17-0.606-0.083l-9.66,4.183C9.596,8.784,9.069,8.873,8.53,8.873C7.777,8.874,6.998,8.699,6.455,8.46C6.262,8.378,6.099,8.285,5.984,8.202C6.026,8.181,6.075,8.16,6.13,8.138l8.787-3.804l1.309,0.561V3.256c0-0.244-0.106-0.475-0.283-0.612c-0.176-0.138-0.407-0.17-0.606-0.083l-9.66,4.183C5.379,6.864,5.124,7.011,4.907,7.227C4.693,7.435,4.51,7.779,4.513,8.161c0,0.011,0.003,0.027,0.003,0.027v14.73c0,0.006-0.001,0.013-0.001,0.019c0,0.005,0.001,0.007,0.001,0.012v0.016h0.002c0.021,0.515,0.28,0.843,0.528,1.075c0.781,0.688,2.091,1.072,3.485,1.092c0.376,0,0.754-0.045,1.126-0.122V11.544c-0.01-0.7,0.27-1.372,0.762-1.856c0.319-0.315,0.708-0.564,1.19-0.756L20.553,5.058z",
        NodeType: nodes.Append,
        OptionsTemplateUrl: tools.TemplatesFolder + "Append.html"
    });
    instance.MaxInputs = 9999;
    instance.HelpUrl = "http://querytreeapp.com/help/tools/append/";

    return instance;
};

tools.LineChart = function() {
    var instance = new tools.ToolBase({ 
        Name: "Line Chart",
        Title: "Line Chart",
        Visible: true,
        Description: "Draw a line chart with lines coming from one or more columns on the source table", 
        SymbolPath: "M3.625,25.062C3.086,24.947000000000003,2.74,24.416,2.855,23.875L2.855,23.875L6.51,6.584L8.777,15.843L10.7,10.655000000000001L14.280999999999999,14.396L18.163999999999998,1.293000000000001L21.098,13.027000000000001L23.058,11.518L28.329,23.258000000000003C28.555,23.762000000000004,28.329,24.353,27.824,24.579000000000004L27.824,24.579000000000004C27.319000000000003,24.806000000000004,26.728,24.579000000000004,26.502000000000002,24.075000000000003L26.502000000000002,24.075000000000003L22.272000000000002,14.647000000000002L19.898000000000003,16.473000000000003L18.002000000000002,8.877000000000002L15.219000000000003,18.270000000000003L11.465000000000003,14.346000000000004L8.386,22.66L6.654999999999999,15.577L4.811999999999999,24.288C4.710999999999999,24.76,4.297,25.082,3.8329999999999993,25.082L3.8329999999999993,25.082C3.765,25.083,3.695,25.076,3.625,25.062L3.625,25.062Z",
        NodeType: nodes.LineChart,
        OptionsTemplateUrl: tools.TemplatesFolder + "LineChart.html"
    });
    instance.MaxInputs = 1;
    instance.AllowImageExport = true;
    instance.HelpUrl = "http://querytreeapp.com/help/tools/line-chart/";

    return instance;
};

tools.BarChart = function() {
    var instance = new tools.ToolBase({ 
        Name: "Bar Chart",
        Title: "Bar Chart",
        Visible: true,
        Description: "Draw a bar chart with the the size of the bars coming from one or more columns on the source table", 
        SymbolPath: "M21.25,8.375V28H27.75V8.375H21.25ZM12.25,28H18.75V4.125H12.25V28ZM3.25,28H9.75V12.625H3.25V28Z",
        NodeType: nodes.BarChart,
        OptionsTemplateUrl: tools.TemplatesFolder + "BarChart.html"
    });
    instance.MaxInputs = 1;
    instance.AllowImageExport = true;
    instance.HelpUrl = "http://querytreeapp.com/help/tools/bar-chart/";

    return instance;
};

tools.PieChart = function () {
    var instance = new tools.ToolBase({
        Name: "Pie Chart",
        Title: "Pie Chart",
        Visible: true,
        Description: "Draw a pie chart with the the size of the segments coming from one of columns on the source table",
        SymbolPath: "M17.203,10.187c0.959,0.194,1.862,0.652,2.62,1.358l6.851-5.207c-0.063-0.073-0.116-0.151-0.182-0.222c-2.5-2.758-5.845-4.275-9.283-4.543L17.203,10.187zM29.744,18.748c0.867-3.688,0.219-7.666-1.97-10.958l-6.838,5.198c0.514,0.974,0.708,2.057,0.597,3.119L29.744,18.748zM21.057,17.867c-0.297,0.629-0.717,1.215-1.266,1.712c-2.236,2.028-5.692,1.86-7.719-0.378c-2.027-2.237-1.86-5.695,0.377-7.723c0.85-0.771,1.876-1.222,2.933-1.365l0.005-8.575c-3.111,0.162-6.188,1.354-8.676,3.612c-5.728,5.198-6.16,14.06-0.964,19.792c5.195,5.729,14.052,6.164,19.781,0.964c1.699-1.543,2.92-3.409,3.679-5.418L21.057,17.867z",
        NodeType: nodes.PieChart,
        OptionsTemplateUrl: tools.TemplatesFolder + "PieChart.html"
    });
    instance.MaxInputs = 1;
    instance.AllowImageExport = true;
    instance.HelpUrl = "http://querytreeapp.com/help/tools/pie-chart/";

    return instance;
};

tools.Summarize = function () {
    var instance = new tools.ToolBase({
        Name: "Summarize",
        Title: "Summarize",
        Visible: true,
        Description: "Displays the statistics for the connected source table2",
        SymbolPath: "M22.646,19.307c0.96-1.583,1.523-3.435,1.524-5.421C24.169,8.093,19.478,3.401,13.688,3.399C7.897,3.401,3.204,8.093,3.204,13.885c0,5.789,4.693,10.481,10.484,10.481c1.987,0,3.839-0.563,5.422-1.523l7.128,7.127l3.535-3.537L22.646,19.307zM13.688,20.369c-3.582-0.008-6.478-2.904-6.484-6.484c0.006-3.582,2.903-6.478,6.484-6.486c3.579,0.008,6.478,2.904,6.484,6.486C20.165,17.465,17.267,20.361,13.688,20.369zM15.687,9.051h-4v2.833H8.854v4.001h2.833v2.833h4v-2.834h2.832v-3.999h-2.833V9.051z",
        NodeType: nodes.Summarize,
        OptionsTemplateUrl: tools.TemplatesFolder + "Summarize.html"
    });

    instance.AggFunctions = ko.observableArray([
        { id: 1, text: "Number of Rows", requiresNumeric: false },
        { id: 2, text: "Total", requiresNumeric: true },
        { id: 3, text: "Minimum", requiresNumeric: true },
        { id: 4, text: "Maximum", requiresNumeric: true },
        { id: 5, text: "Average", requiresNumeric: true },
        { id: 6, text: "Median", requiresNumeric: true }
    ]);

    instance.DateFunctions = ko.observableArray([
        { id: 1, text: "Date" },
        { id: 2, text: "Month" },
        { id: 3, text: "Year" },
    ]);

    instance.MaxInputs = 1;
    instance.HelpUrl = "http://querytreeapp.com/help/tools/statistics/";

    return instance;
};

tools.Extract = function () {
    var instance = new tools.ToolBase({
        Name: "Extract",
        Title: "Extract",
        Visible: true,
        Description: "Makes a new column by extracting text from within another column",
        SymbolPath: "M14.505,5.873c-3.937,2.52-5.904,5.556-5.904,9.108c0,1.104,0.192,1.656,0.576,1.656l0.396-0.107c0.312-0.12,0.563-0.18,0.756-0.18c1.128,0,2.07,0.411,2.826,1.229c0.756,0.82,1.134,1.832,1.134,3.037c0,1.157-0.408,2.14-1.224,2.947c-0.816,0.807-1.801,1.211-2.952,1.211c-1.608,0-2.935-0.661-3.979-1.984c-1.044-1.321-1.565-2.98-1.565-4.977c0-2.259,0.443-4.327,1.332-6.203c0.888-1.875,2.243-3.57,4.067-5.085c1.824-1.514,2.988-2.272,3.492-2.272c0.336,0,0.612,0.162,0.828,0.486c0.216,0.324,0.324,0.606,0.324,0.846L14.505,5.873zM27.465,5.873c-3.937,2.52-5.904,5.556-5.904,9.108c0,1.104,0.192,1.656,0.576,1.656l0.396-0.107c0.312-0.12,0.563-0.18,0.756-0.18c1.104,0,2.04,0.411,2.808,1.229c0.769,0.82,1.152,1.832,1.152,3.037c0,1.157-0.408,2.14-1.224,2.947c-0.816,0.807-1.801,1.211-2.952,1.211c-1.608,0-2.935-0.661-3.979-1.984c-1.044-1.321-1.565-2.98-1.565-4.977c0-2.284,0.449-4.369,1.35-6.256c0.9-1.887,2.256-3.577,4.068-5.067c1.812-1.49,2.97-2.236,3.474-2.236c0.336,0,0.612,0.162,0.828,0.486c0.216,0.324,0.324,0.606,0.324,0.846L27.465,5.873z",
        NodeType: nodes.Extract,
        OptionsTemplateUrl: tools.TemplatesFolder + "Extract.html"
    });
    instance.MaxInputs = 1;

    instance.StartTypes = ko.observableArray([
        { id: 1, text: "The beginning" },
        { id: 2, text: "At a specific position" },
        { id: 3, text: "At the first occurrence of..." },
        { id: 4, text: "After the first occurrence of..." },
    ]);

    instance.EndTypes = ko.observableArray([
        { id: 1, text: "The end" },
        { id: 2, text: "At a specific position" },
        { id: 3, text: "At a specific length" },
        { id: 4, text: "At the next occurrence of..." },
        { id: 5, text: "After the next occurrence of..." },
    ]);

    instance.HelpUrl = "http://querytreeapp.com/help/tools/extract/";

    return instance;
}

tools.IsNumericType = function (theType) {
    switch (theType.toUpperCase()) {
        case "INTEGER":
        case "INT":
        case "SMALLINT":
        case "TINYINT":
        case "MEDIUMINT":
        case "BIGINT":
        case "DECIMAL":
        case "NUMERIC":
        case "FLOAT":
        case "DOUBLE":
        case "REAL":
        case "MONEY":
        case "SMALLMONEY":
        case "DOUBLE PRECISION":
        case "SMALLSERIAL":
        case "SERIAL": 
        case "BIGSERIAL":
        case "INT4":
        case "INT8":
            return true;
        default:
            return false;
    }
}

tools.IsDatetimeType = function (theType) {
    switch (theType.toUpperCase()) {
        case "DATE":
        case "DATETIME":
        case "DATETIME2":
        case "TIME":
        case "TIMESTAMP":
        case "TIMESTAMP WITHOUT TIME ZONE":
        case "TIMESTAMP WITH TIME ZONE":
        case "DATE":
        case "TIME WITHOUT TIME ZONE":
        case "TIME WITH TIME ZONE":
        case "INTERVAL":
            return true;
        default:
            return false;
    }
}

tools.IsTextType = function (theType) {
    switch (theType.toUpperCase()) {
        case "VARCHAR":
        case "NVARCHAR":
        case "CHAR":
        case "NCHAR":
        case "TEXT":
        case "NTEXT":
        case "XML":
        case "UNIQUEIDENTIFIER":
        case "BINARY":
        case "VARBINARY":
        case "IMAGE":
        case "ENUM":
        case "CHARACTER VARYING":
        case "CHARACTER":
        case "TEXT":
        case "LONGTEXT":
        case "USER-DEFINED": // Treat any user defined columns as text
            return true;
        default:
            return false;
    }
}

// 'utils' Module
//
// Depends on: nothing

utils = {};

utils.CreateGuid = function() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
        return v.toString(16);
    });
};

utils.FormatDateTime = function(date, time) {
    if (date != undefined && time != undefined) {
        return moment(date).format("YYYY-MM-DD") + " " + time;
    }
    return null;
};

utils.GetParameterByName = function (name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

utils.GetHiddenValByName = function (name) {
    return $("input[name='"+name+ "']").val()
}

//xAxisType = self.selectedNode().ColumnTypes()[xAxis])
utils.RenderChart = function (resultsContainer, data, graphType, xIndex, xAxisType, yIndex, yAxisType) {
    if (data && data.length > 0) {

        var svgWidth = $(resultsContainer).innerWidth();
        var svgHeight = 460;

        var margin = { top: 20, right: 20, bottom: 40, left: 50 };

        if (svgWidth - margin.left - margin.right > 600) {
            var extraMargin = Math.floor((svgWidth - margin.left - margin.right - 600) / 2);
            margin.left += extraMargin;
            margin.right += extraMargin;
        }

        var width = svgWidth - margin.left - margin.right;
        var height = 400;


        switch (graphType) {
            case "Line Chart":
                var theData = data.slice();
                theData.sort(function (a, b) {
                    if (a[xIndex] < b[xIndex]) {
                        return -1;
                    }
                    if (a[xIndex] > b[xIndex]) {
                        return 1;
                    }
                    // a must be equal to b
                    return 0;
                });

                var xScale, xAxis, xSelector;
                if (tools.IsDatetimeType(xAxisType)) {
                    xSelector = function (d) { return new Date(d[xIndex]); };

                    xScale = d3.time.scale()
                        .domain(d3.extent(theData, xSelector))
                        .range([0, width]);

                    xAxis = d3.svg.axis()
                        .scale(xScale)
                        .orient("bottom")
                        .ticks(5);
                } else {
                    xSelector = function (d) { return d[xIndex]; };

                    xScale = d3.scale.linear()
                        .domain(d3.extent(theData, xSelector))
                        .range([0, width]);

                    xAxis = d3.svg.axis()
                        .scale(xScale)
                        .orient("bottom")
                        .ticks(5);
                }


                var ySelector = function (d) { return d[yIndex]; };

                var min = 0;
                var max = Math.max.apply(null, theData.map(ySelector));

                var yScale = d3.scale.linear()
                    .domain([min, max])
                    .range([height, 0]);

                var yAxis = d3.svg.axis()
                    .scale(yScale)
                    .orient("left")
                    .ticks(5);

                var parent = $(resultsContainer).empty();

                // create svg
                var svg = d3.select('#' + parent.attr('id'))
                    .append('svg')
                    .attr("width", svgWidth)
                    .attr("height", svgHeight);

                var inner = svg.append("g")
                   .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

                // x axis
                var xAxisGroup = inner.append("g")
                        .attr("transform", "translate(0," + height + ")");

                xAxisGroup.call(xAxis)

                xAxisGroup.selectAll("line,path")
                    .attr("fill", "none")
                    .attr("stroke", "#333333")
                    .attr("shape-rendering", "crispEdges");

                xAxisGroup.selectAll("text")
                    .attr("font-family", "sans-serif")
                    .attr("text-anchor", "end")
                    .attr("font-size", "11px");

                // y axis
                var yAxisGroup = inner.append("g");

                yAxisGroup.call(yAxis);

                yAxisGroup.selectAll("text")
                    .attr("font-family", "sans-serif")
                    .attr("text-anchor", "end")
                    .attr("font-size", "11px");

                yAxisGroup.selectAll("line,path")
                    .attr("fill", "none")
                    .attr("stroke", "#333333")
                    .attr("shape-rendering", "crispEdges");

                var line = d3.svg.line()
                .x(function (d) {
                    return xScale(xSelector(d));
                })
                .y(function (d) {
                    return yScale(ySelector(d));
                });

                // create lines
                inner.append("path")
                    .datum(theData)
                    .attr("fill", "none")
                    .attr("d", line)
                    .attr("stroke", "rgb(100, 100, 255)")
                    .attr("stroke-width", "1px");
                break;
            case "Bar Chart":
                var xSelector = function (d) { return d[xIndex]; };
                var ySelector = function (d) { return d[yIndex]; };

                var theData = data.slice(0, 25);

                var xScale = d3.scale.ordinal()
                    .domain(d3.range(theData.length))
                    .rangeRoundPoints([0, width], 1)

                var xAxis = d3.svg.axis()
                    .scale(xScale)
                    .orient("bottom")
                    .ticks(theData.length)
                    .tickFormat(function (d) {
                        return xSelector(theData[d])
                    });

                var min = 0; //Math.min.apply(null, theData.map(function (row) { return Math.min.apply(null, row.slice(1)) }));;
                var max = Math.max.apply(null, theData.map(ySelector));


                var yScale = d3.scale.linear()
                    .domain([min, max])
                    .range([height, 0]);

                var yAxis = d3.svg.axis()
                    .scale(yScale)
                    .orient("left")
                    .ticks(5);

                var parent = $(resultsContainer).empty();

                // create svg
                var svg = d3.select('#' + parent.attr('id'))
                    .append('svg')
                    .attr("width", svgWidth)
                    .attr("height", svgHeight);

                var inner = svg.append("g")
                   .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

                // x axis
                var xAxisGroup = inner.append("g")
                        .attr("transform", "translate(0," + height + ")");

                xAxisGroup.call(xAxis);

                xAxisGroup.selectAll("line,path")
                    .attr("fill", "none")
                    .attr("stroke", "#333333")
                    .attr("shape-rendering", "crispEdges");

                xAxisGroup.selectAll(".domain")
                    .attr("stroke", "none");

                xAxisGroup.selectAll("text")
                    .style("text-anchor", "end")
                    .attr("dx", "-.8em")
                    .attr("dy", ".15em")
                    .attr("transform", "rotate(-65)")
                    .attr("font-family", "sans-serif")
                    .attr("text-anchor", "end")
                    .attr("font-size", "11px");


                // y axis
                var yAxisGroup = inner.append("g");

                yAxisGroup.call(yAxis);

                yAxisGroup.selectAll("text")
                    .attr("font-family", "sans-serif")
                    .attr("text-anchor", "end")
                    .attr("font-size", "11px");

                yAxisGroup.selectAll("line,path")
                    .attr("fill", "none")
                    .attr("stroke", "#333333")
                    .attr("shape-rendering", "crispEdges");

                var xOffset = 0;
                var xSpace = width / theData.length;
                if (theData.length > 1) {
                    var range = xScale.range();
                    xSpace = range[1] - range[0];
                    for (var i = 1; i + 1 < theData.length; i++) {
                        var diff = range[i + 1] - range[i]
                        if (diff < xSpace) {
                            xSpace = diff;
                        }
                    }
                    xOffset = range[0] - (xSpace / 2);
                }

                var bars = inner.append("g")
                    .selectAll("g")
                    .data(theData)
                    .enter().append("g")
                    .attr("transform", function (d, j) { return "translate(" + (xOffset + (j * xSpace)) + ",0)"; });

                var barMargin = 6;
                var barWidth = xSpace - (2 * barMargin);

                bars.append("rect")
                    .attr("x", barMargin)
                    .attr("y", function (d) { return yScale(ySelector(d)); })
                    .attr("height", function (d) { return height - yScale(ySelector(d)); })
                    .attr("width", barWidth - 1)
                    .on('mouseover', function (d) {
                        d3.select(this.parentNode).selectAll("rect").attr("opacity", 0.8);
                        d3.select(this.parentNode).selectAll("text").attr("fill", "black");
                    }).on('mouseout', function (d) {
                        d3.select(this.parentNode).selectAll("rect").attr("opacity", 1);
                        d3.select(this.parentNode).selectAll("text").attr("fill", "none");
                    })
                    .attr("fill", "rgb(255, 100, 100)");

                bars.append("text")
                    .attr("text-anchor", "middle")
                    .attr("fill", "none")
                    .attr("x", barMargin + (.5 * barWidth))
                    .attr("y", function (d) { return yScale(ySelector(d)) - 3; })
                    .text(function (d) { return ySelector(d); });

                svg.attr("height", $('svg > g').get(0).getBBox().height + 6);

                $(".bar").css("background-color", "Red");
                break;
            case "Pie Chart":
                var radius = Math.min(width, height) / 2;

                var unfilteredData = data.slice(0, 25);
                var total = unfilteredData.reduce(function (curr, row) { return curr + row[yIndex]; }, 0);

                var other = 0;
                var theData = [];

                $.each(unfilteredData, function (i, row) {
                    if (total != 0) {
                        var percentage = 100 * row[yIndex] / total;
                        if (percentage >= 1) {
                            theData.push([row[xIndex], row[yIndex], percentage, false]);
                        } else {
                            other += row[yIndex];
                        }
                    } else {
                        theData.push([row[xIndex], row[yIndex], null, false]);
                    }
                });

                if (other > 0) {
                    theData.push(["Other", other, total != 0 ? other / total : null, true]);
                }


                theData.sort(function (a, b) {
                    if (a[1] < b[1]) {
                        return -1;
                    }
                    if (a[1] > b[1]) {
                        return 1;
                    }
                    // a must be equal to b
                    return 0;
                });


                var xSelector = function (d) { return d[xIndex]; };
                var ySelector = function (d) { return d[yIndex]; };

                var pie = d3.layout.pie()
                    .sort(null)
                    .startAngle(-0.25 * Math.PI)
                    .endAngle(1.75 * Math.PI)
                    .value(function (d) {
                        return d[1];
                    });

                var arc = d3.svg.arc()
                    .outerRadius(radius * 0.8)
                    .innerRadius(radius * 0.4);

                var outerArc = d3.svg.arc()
                    .outerRadius(radius * 0.9)
                    .innerRadius(radius * 0.9);

                var parent = $(resultsContainer).empty();

                // create svg
                var svg = d3.select('#' + parent.attr('id'))
                    .append('svg')
                    .attr("width", width + margin.left + margin.right)
                    .attr("height", height + margin.top + margin.bottom);

                var g = svg.append("g")
                   .attr("transform", "translate(" + (margin.left + (width / 2)) + "," + (margin.top + (height / 2)) + ")");

                var lineFunction = d3.svg.line()
                    .x(function (d) { return d[0]; })
                    .y(function (d) { return d[1]; })
                    .interpolate("linear");

                var getLabel = function (segment) {
                    var result = segment.data[0]

                    //if (instance.LabelType() == "Name and Value") {
                    result += " (" + segment.data[1] + ")";
                    //} else if (instance.LabelType() == "Name and Percentage") {
                    //    if (segment.data[2] != null) {
                    //        result += " (" + parseFloat(segment.data[2].toPrecision(3)) + "%)";
                    //    } else {
                    //        result += " (" + segment.data[1] + ")";
                    //    }
                    //}
                    return result;
                }


                var colours = ['#98abc5', '#8a89a6', '#7b6888', '#6b486b', '#a05d56', '#d0743c', '#ff8c00', '#7283a2'];

                var otherColour = '#BBB';

                $.each(pie(theData), function (i, segment) {
                    var segmentGrp = g.append("g"),
                        innerPoint = arc.centroid(segment),
                        outerPoint = outerArc.centroid(segment),
                        onLeftSide = outerPoint[0] < 0,
                        textPoint = [onLeftSide ? -radius : radius, outerPoint[1]];

                    var slice = segmentGrp.append("path")
                        .attr("fill", (segment.data[3] ? otherColour : colours[i % colours.length]))
                        .attr("d", arc(segment));

                    var lineGraph = segmentGrp.append("path")
                        .attr("d", lineFunction([innerPoint, outerPoint, textPoint]))
                        .attr("stroke", "black")
                        .attr("stroke-width", 1)
                        .attr("fill", "none");

                    var text = segmentGrp.append("text")
                        .text(getLabel(segment))
                        .attr('x', textPoint[0])
                        .attr('y', textPoint[1])
                        .attr('text-anchor', onLeftSide ? 'end' : 'start')
                        .attr('alignment-baseline', 'middle');

                })

                break;
            default:
                $(resultsContainer).empty();
        }

    } else {
        $(resultsContainer).empty();
    }
}
// 'backend' Module
//
// Depends on: utils.js

backend = {
    "baseUri": ""
};

(function () {

    backend.CheckConnection = function (models, callback) {
        var databaseId = utils.GetHiddenValByName('DatabaseConnectionID');
        $.getJSON(backend.baseUri + "/api/connections/" + databaseId + "/status/", function (data) {
            callback(data);
        });
    };

    backend.LoadTables = function (callback) {
        var databaseId = utils.GetHiddenValByName('DatabaseConnectionID');
        $.getJSON(backend.baseUri + "/api/connections/" + databaseId + "/tables/", function (data) {
            callback(data);
        })
        .fail(function () {
            callback([]);
        });
    };

    backend.GetJoins = function (tableName, callback) {
        var databaseId = utils.GetHiddenValByName('DatabaseConnectionID');
        $.getJSON(backend.baseUri + "/api/connections/" + databaseId + "/tables/" + tableName + "/joins/", function (data) {
            callback(data);
        })
        .fail(function () {
            callback([]);
        });
    };

    var lock = false,
        callbacks = [],
        latestNodes = null;

    backend.SaveQuery = function (serverQueryKey, nodes, callback) {
        if (callback) {
            callbacks.push(callback);
        }

        if (lock) {
            latestNodes = nodes;
        } else {
            lock = true;
            latestNodes = null;
            $.ajax({
                "url": backend.baseUri + "/api/cache/",
                "type": 'POST',
                "data": {
                    id: serverQueryKey(),
                    databaseId: utils.GetHiddenValByName('DatabaseConnectionID'),
                    nodes: JSON.stringify(nodes)
                },
                "dataType": "json"
            }).done(function (data) {
                serverQueryKey(data.id);
                lock = false;

                // if we have callbacks then obviously something changed while we were getting results, add this callback to queue and resave to get latest data
                if (latestNodes) {
                    var tmp = latestNodes;
                    latestNodes = null;
                    backend.SaveQuery(serverQueryKey, tmp);
                } else {
                    while (callbacks.length > 0) {
                        callbacks.shift()();
                    }
                }
            }).fail(function () {
                lock = false;
                latestNodes = null;
                callbacks.length = 0;
            });
        }
    }

    backend.LoadData = function (serverQueryKey, nodes, nodeId, startRow, rowCount, format, output, callback) {
        if (!serverQueryKey()) {
            backend.SaveQuery(serverQueryKey, nodes, function () {
                backend.LoadData(serverQueryKey, nodes, nodeId, startRow, rowCount, format, output, callback);
            });
        } else {
            $.getJSON(backend.baseUri + "/api/cache/" + serverQueryKey() + "/" + nodeId + "/?startRow=" + startRow + "&rowCount=" + rowCount, function (data) {
                if (data.query) {
                    console.log(data.query);
                }
                callback(data);
            })
            .fail(function (jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == "404") {
                    serverQueryKey(null);
                    backend.LoadData(serverQueryKey, nodes, nodeId, startRow, rowCount, format, output, callback);
                } else {
                    callback({ status: "error" })
                }
            });
        }
    };

    backend.SaveSchedule = function (schedule, callback) {
        $.ajax({
            "url": backend.baseUri + '/api/schedule',
            "type": 'POST',
            "contentType": "application/json",
            "data": JSON.stringify(schedule),
            "dataType": "json"
        }).done(function (data) {
            callback(data);
        }).fail(function (data) {
            callback(data);
        });
    }

    backend.GetSchedule = function (queryId) {
        return $.ajax({
            "url": backend.baseUri + '/api/schedule?id=' + queryId,
            "type": 'GET',
            "contentType": "application/json",
            "dataType": "json"
        });
    }

    backend.LoadQueryColumnsName = function (queryId) {
        return $.ajax({
            "url": backend.baseUri + "/api/queries/" + queryId + "/columns/",
            "type": 'GET'
        });
    };
})();